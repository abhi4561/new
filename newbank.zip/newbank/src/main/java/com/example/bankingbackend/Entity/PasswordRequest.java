package com.example.bankingbackend.Entity;
public class PasswordRequest {
    private String password;

    // Getter and Setter

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
