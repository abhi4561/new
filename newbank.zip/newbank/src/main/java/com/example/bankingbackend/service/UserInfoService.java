package com.example.bankingbackend.service;

import com.example.bankingbackend.Entity.UserInfo;
import org.springframework.security.core.userdetails.UserDetailsService;
public interface UserInfoService extends UserDetailsService {
	UserInfo findByEmail(String emailId);
	UserInfo saveUser(UserInfo user);
}
