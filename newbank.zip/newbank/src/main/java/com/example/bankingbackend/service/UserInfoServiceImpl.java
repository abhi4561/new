package com.example.bankingbackend.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.bankingbackend.Entity.UserInfo;
import com.example.bankingbackend.repository.UserInfoRepository;

@Service
public class UserInfoServiceImpl implements UserInfoService, UserDetailsService {

    @Autowired
    private UserInfoRepository userRepository;

    @Override
    public UserInfo findByEmail(String emailId) {
        return userRepository.findByemailId(emailId);
    }

    @Override
    public UserInfo saveUser(UserInfo user) {
        return userRepository.save(user);
    }

    @Override
    public UserDetails loadUserByUsername(String emailId) throws UsernameNotFoundException {
        UserInfo user = userRepository.findByemailId(emailId);
        if (user == null) {
            throw new UsernameNotFoundException("User not found");
        }
        return new org.springframework.security.core.userdetails.User(
                user.getEmailId(),
                user.getpassword(),
                new ArrayList<>()
        );
    }
}
